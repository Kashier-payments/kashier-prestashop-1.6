<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{kashier}prestashop>validation_e2b7dec8fa4b498156dfee6e4c84b156'] = 'طريقه الدفع هذه غير متاحه';
$_MODULE['<{kashier}prestashop>infos_2b7119559ef4a1d487485cdb6098d0d4'] = 'تسمح لك هذه الوحدة بقبول المدفوعات بآمان بواسطة كاشير';
$_MODULE['<{kashier}prestashop>infos_f9c4af9fa8bedaca6f267d9531c8bb93'] = 'يقبل كاشير جميع طرق الدفع الشائعة ، يمكنك إنشاء تجربة دفع سلسة لعملائك';
$_MODULE['<{kashier}prestashop>payment_execution_644818852b4dd8cf9da73543e30f045a'] = ' العودة لصفحة الدفع ';
$_MODULE['<{kashier}prestashop>payment_execution_6ff063fbc860a79759a7369ac32cee22'] = 'أدفع';
$_MODULE['<{kashier}prestashop>payment_execution_1d107f0eaf38c30770dcdd702ea09b1b'] = 'دفع بالكارت (كاشير)';
$_MODULE['<{kashier}prestashop>payment_execution_f1d3b424cd68795ecaa552883759aceb'] = 'ملخص الطلب';
$_MODULE['<{kashier}prestashop>payment_execution_879f6b8877752685a966564d072f498f'] = 'سلة مشترياتك فارغة';
$_MODULE['<{kashier}prestashop>payment_execution_4de70f80016440f94ea9790d7777dd6a'] = 'دفع بالكارت';
$_MODULE['<{kashier}prestashop>payment_execution_f35b7d62ea5a3aaf15dd98501d4fae4e'] = 'انت اخترت الدفع بواسطه الكارت ';
$_MODULE['<{kashier}prestashop>payment_execution_c884ed19483d45970c5bf23a681e2dd2'] = 'هنا ملخص قصير لطلبك';
$_MODULE['<{kashier}prestashop>payment_execution_e2867a925cba382f1436d1834bb52a1c'] = 'المبلغ الإجمالى لطلبك';
$_MODULE['<{kashier}prestashop>payment_execution_1f87346a16cf80c372065de3c54c86d9'] = 'شامل الضريبة';
$_MODULE['<{kashier}prestashop>payment_execution_35b1f55feebe4a45d053cd051a0792b7'] = 'نحن نسمح بإرسال عدة عملات خلال كاشير';
$_MODULE['<{kashier}prestashop>payment_execution_a7a08622ee5c8019b57354b99b7693b2'] = 'إختر واحدا مما يلى';
$_MODULE['<{kashier}prestashop>payment_execution_be9ef3e92fbcb342e2609ef28fca6768'] = 'نحن نسمح بإرسال العملة التالية عن طريق الكاشير';
$_MODULE['<{kashier}prestashop>payment_execution_be926240eb2ccf48df0767563953364d'] = 'سيتم عرض معلومات حساب كاشير في الصفحة التالية';
$_MODULE['<{kashier}prestashop>payment_execution_7de7697be224bbfdb718c4da7e5787fa'] = 'يُرجى تأكيد طلبك بالنقر فوق \"ادفع الآن\"';
$_MODULE['<{kashier}prestashop>payment_execution_569fd05bdafa1712c4f6be5b153b8418'] = 'طرق دفع اخري';
$_MODULE['<{kashier}prestashop>kashier_1c481aa99d081c32182011a758f73d33'] = '%s';
$_MODULE['<{kashier}prestashop>payment_return_88526efe38fd18179a127024aba8c1d7'] = 'طلبك علي %s تم بنجاح';
